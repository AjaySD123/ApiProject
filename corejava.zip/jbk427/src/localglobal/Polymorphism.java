package localglobal;
import java.util.Scanner;
public class Polymorphism {
	int studid ;
	String	sudname;
	int marks;
	public int getStudid() {
		return studid;
	}
	public void setStudid(int studid) {
		this.studid = studid;
	}
	public String getSudname() {
		return sudname;
	}
	public void setSudname(String sudname) {
		this.sudname = sudname;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	

}
