package localglobal;
import java.util.Scanner ;
public class Main_poly {
static Scanner sc =new Scanner (System.in) ;

	public static void main(String[] args) {
		Polymorphism obj=new Polymorphism() ;
		System.out.println("Enter the Stud id ");
		int studid = sc.nextInt();
		System.out.println("Enter the Student Name ");
		String studname=sc.next();
		System.out.println(obj.getStudid() );
		
		
	}

}
