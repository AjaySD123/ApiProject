package com.jbk.basic;
import java. util. Scanner;
public class practiceoverload {
static Scanner sc= new Scanner (System.in);
public void sum (){
	
}
}
