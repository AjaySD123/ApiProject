package com.jbk.basic;
import java.util.Scanner;
public class assignment25 {
static Scanner sc = new Scanner (System.in);
	public static void main(String[] args) {
		// to find out the area of circle 
		double r ;
		double a=3.14;
		System.out.println("enter the radius value ");
		r=sc .nextInt();
		 double area = a*r*r;
System.out.println("area of circle = "+area);	}

}
