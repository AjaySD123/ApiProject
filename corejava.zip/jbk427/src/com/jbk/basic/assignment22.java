package com.jbk.basic;

public class assignment22 {

	public static void main(String[] args) {
	int no1;
	no1=45;
    int squ= no1*no1;
System.err.println("square="+squ);
	}

}
