package com.jbk.basic;
import java.util.Scanner;
public class assignment23 {
	static Scanner sc=new Scanner (System.in);
	public static void main(String s[])
	{int no1;
	System.out.println("enter a number ");
	no1=sc.nextInt();
		
		
		int cube = no1*no1*no1;
		System.err.println("cube="+cube);
	}

}
