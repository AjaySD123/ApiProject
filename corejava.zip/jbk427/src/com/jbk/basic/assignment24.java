package com.jbk.basic;

public class assignment24 {

	public static void main(String[] args) {
		//to find out the area of rectangle 
		float l,w ;
		l=45.36f;
		w=36.55f;
				float area = l*w;
		System.err.println("area of rectangle ="+area);

	}

}
