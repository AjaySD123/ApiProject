package com.jbk.basic;

public class assignment1 {

	 int getNo() {
	return 0;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println("java by kiran ");
 System.out.print("karvenagar ");
 System.err.println(3);
 System.err.println(3+4);
 System.out.println(3-4);
 System.err.println(3*4);
 System.err.println(3/4);
 
 
	}

}
