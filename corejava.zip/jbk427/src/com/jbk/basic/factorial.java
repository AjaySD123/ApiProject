package com.jbk.basic;
import java.util.Scanner;
public class factorial {
static Scanner sc=new Scanner (System.in);
	
    void factorial(){
	int Factorial=0;
	int a ;
	for (int i=0;i<=5;i++){
		
		System.out.println("enter a number ");
		 a=sc.nextInt();
		Factorial =a*a+i;

		System.out.println("The Factorial is ="+Factorial);}


		 
	
    
    
}
}