package com.jbk.basic;

public class assignments {

	public static void main(String[] args) {
		float no1,no2,no3;
		no1=5.3f;
		no2=4.7f;
		no3=8.6f;
		float ans = (no1+no2+no3)/3;
System.out.println("avg="+ans);
factorial obj=new  factorial();
obj.factorial();
	}
	

}
