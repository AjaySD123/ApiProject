package com.java.array;
import java.util.Scanner;
public class Maincustomer {
static Scanner sc=new Scanner (System.in);
	public static void main(String[] args) {
		Customer obj=new Customer();
		
	}

}
