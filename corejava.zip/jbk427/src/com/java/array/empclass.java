package com.java.array;
import java.util.Scanner;
public class empclass {
static Scanner sc=new Scanner (System.in);
int empid ;
char empnm;

	public int getEmpid() {
		System.out.println("ener the empid");
	return empid;
}

public void setEmpid(int empid) {
	System.out.println("");
	this.empid = empid;
}

public char getEmpnm() {
	return empnm;
}

public void setEmpnm(char empnm) {
	this.empnm = empnm;
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
