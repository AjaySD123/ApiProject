package com.java.array;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;
public class arraysort {
static Scanner sc=new Scanner (System.in);
Integer a[] = new Integer [5];

void setdata (){
	System.out.println("enter the 5 array element ");
	for (int i=0;i<5;i++){
	a[i]=sc.nextInt();	
	}}
void sortdata()
{
	System.out.println("before sorting ");
	for (int i=0;i<5;i++)
		System.out.println(a[i]);
	Arrays.sort(a,Collections.reverseOrder());
	System.out.println("After sorting ");
	for (int i=0;i<5;i++)
		System.out.println(a[i]);
}


	public static void main(String[] args) {
		arraysort obj=new arraysort();
		obj.setdata ();
		obj.sortdata();
	}

}
