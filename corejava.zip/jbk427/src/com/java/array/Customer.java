package com.java.array;

public class Customer {
int custid ;
String custNM;
public int getCustid() {
	return custid;
}
public void setCustid(int custid) {
	this.custid = custid;
}
public String getCustNM() {
	return custNM;
}
public void setCustNM(String custNM) {
	this.custNM = custNM;
}

}
