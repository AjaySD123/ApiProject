package com.java.array;
import java .util.Scanner;
public class exersize {
static Scanner sc=new Scanner (System.in);


	int arr[]=new int [10];
	void accept(){
		int ocnt=0,ecnt=0;
		System.out.println("enter the 10 int values ");
	for (int i= 0;i<10; i++)
	{
		arr[i]=sc.nextInt();
		if (arr[i]%2==0)
			ecnt++;
			else
				ocnt++;
	
			
	}
	System.out.println("even count"+ecnt);
	System.out.println("odd count"+ocnt);

	
}
	public static void main(String[] args) {
		
		exersize obj=new exersize() ;
		obj.accept();
	}

}
