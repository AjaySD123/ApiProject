package com.java.practical;
import java.util.Scanner;
public class calculATEsum {
static Scanner sc=new Scanner (System.in);
void sum(){
	int s=0;
	System.out.println("enter the 5 no");
	for (int i=1;i<=5;i++){
		int no=sc.nextInt();
		s=s+no;
	}
	System.out.println(s);
}
}
