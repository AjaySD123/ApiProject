package com.java.exception;
import java .util.Scanner;
public class operaions {
static Scanner sc=new Scanner (System.in);
void divide(){
	try{
		
	
	System.out.println("enter the first no ");
	double  no=sc.nextDouble();
	System.out.println("enter the seccond no1");
	double  no1=sc.nextDouble ();
	System.out.println("Answer "+(no/no1));
	}
	catch (java.lang.ArithmeticException e){
		System.out.println("number can not be divide by zero");
	}
	catch (java.util.InputMismatchException e){
		System.out.println("pls enter valid data type");
	}
	finally {
		sc.close();
		System.out.println("finally");
	}
	
}
	public static void main(String[] args) {
		operaions obj=new operaions() ;
		obj.divide();
	}

}
