package com.java.exception;
import java.util.Scanner ;
public class Product {
private int prodid; 
private String prodname ;
private float prodcost ;
	public int getProdid() {
	return prodid;
}
	public void setProdid(int prodid) {
	this.prodid = prodid;
}
	public String getProdname() {
	return prodname;
}
	public void setProdname(String prodname) {
	this.prodname = prodname;
}
	public float getProdcost() {
	return prodcost;
}
	public void setProdcost(float prodcost) {
	this.prodcost = prodcost;
}

}
