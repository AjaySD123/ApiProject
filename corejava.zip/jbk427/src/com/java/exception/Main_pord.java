package com.java.exception;

public class Main_pord {

	public static void main(String[] args) {
		Product p=new Product();
	

	}

}
