package com.java.scannewr;
import java. util.Scanner;
public class avarage {
static Scanner s= new Scanner (System.in);
void avg (){
int a=0;
int b=0;
int c=0;
int d=0;
System.out.println("enter the first number ");
  a=s.nextInt();
  b=s.nextInt();
 c=s.nextInt();
 d=s.nextInt();
float avg = ((a+ b + c + d )/4);
System.out.println("the averageis "+avg);

}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
avarage obj= new avarage();
obj. avg();
System.out.println();
	}

}
 