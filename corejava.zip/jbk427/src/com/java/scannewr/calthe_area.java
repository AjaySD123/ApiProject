package com.java.scannewr;
import java.util.Scanner;
// write the program to calculate the various shape area
public class calthe_area {
static Scanner sc=new Scanner (System.in);
void select (){
int rect=0 ;
int circle =0;
int square=0; 
int area =0;
System.out.println("pls select the shape ");
if( rect ==0) {
	System.out.println("the are ");
	
	
	

}
	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
