package com.java.scannewr;
import java . util .Scanner; 

public class add{
	
	 static Scanner sc = new Scanner (System.in);



 void sumo(){
		int num1;
		int num2;
		
System.out.println("enter the firs number ");
num1 = sc.nextInt();
System.out.println("enter the second  number ");
num2 = sc.nextInt();

int s = num1+num2;

System.out.println("the sum is "+s);
 }
 public static void main(String[] args) {
	 add obj=new add();
	 obj.sumo();
}
}
