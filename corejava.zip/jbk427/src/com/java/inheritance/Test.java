package com.java.inheritance;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car c1=new Car();
		c1.getColor();
		c1.color ="red";
		c1.setSpeed(200);
		c1.setSize(25);
		c1.cc=2500;
		c1.gears=5;
		System.out.println("Color of car "+c1.color);
		System.out.println("Speed of car "+c1.getSpeed());
		System.out.println("size of car "+c1.getSize());
		System.out.println("CC of car "+c1.cc);
		System.out.println("Gear of car "+c1.gears);
	}

}
