package com.java.encapsulation;
 import java .util.Scanner;
public class Main_student {
static Scanner sc=new Scanner (System.in);

	public static void main(String[] args) {
	
	
		
		Student s=new Student();
		
		
		System.out.println("ENter a Student id ");
		int Studid=sc.nextInt();
		System.out.println("enter the Student name ");
		String studnm =sc.next();
	System.out.println("Enter the course name ");
	String cnm=sc.next();
	s.setStudid(Studid);
	s.setStudnm(studnm);
	s.setCnm(cnm);

	System.out.println(s.getStudid());
	System.out.println(s.getStudnm());
	System.out.println(s.getCnm());
	}}
		
