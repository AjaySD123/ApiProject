package com.java.main.demmo;
import java.util.Scanner;
public class factorial {
	static Scanner sc=new Scanner (System.in);
	int i; int fact;
void factorialy (){
	int no=0;
	System.out.println("enter a number ");
	int n=sc.nextInt();
	for(i=1;i<=no;i--){
	
	int fact = no*i;
	}
	System.out.println(fact);
}
public static void main(String[] args) {
	factorial obj=new factorial ();
	obj.factorialy();
}
}
