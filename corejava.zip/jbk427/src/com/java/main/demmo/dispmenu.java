package com.java.main.demmo;
import java.util.Scanner;

public class dispmenu {
	 static  Scanner sc =new Scanner(System.in);
	 
	
}
	
	
	
	