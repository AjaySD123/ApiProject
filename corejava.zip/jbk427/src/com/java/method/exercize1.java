package com.java.method;

public class exercize1 {
int a;
float b ;

public void Operation1 (){
	a=10; 
	b=12.007f;

	
}
public void Operation2(){
	a=20;
	b=45.0f;

	
}
public void display (){
	System.out.println("imteger value is"+a);
	System.out.println("the float value is "+b);
	
}

}
