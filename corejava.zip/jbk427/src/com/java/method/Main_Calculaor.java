package com.java.method;
import java.util.Scanner;
public class Main_Calculaor {

	public static void main(String[] args) {
		Calculator c=new Calculator();
		Scanner sc=new Scanner (System.in);
		int choice ;
		do{
		System.out.println("Enter ur choise ");
		System.out.println("1.Add");
		System.out.println("2.Sub");
		System.out.println("3.Prod");
		System.out.println("4.Div");
		int ch =sc.nextInt();
		switch (ch)
		{
		case 1:
		{
		System.out.println("Enter the two number ");
		int no=sc.nextInt ();
		int no1=sc.nextInt();
		c.Add(no, no1);
		break;
		}
		case 2:
		{
		System.out.println("Enter the two number ");
		int no=sc.nextInt ();
		int no1=sc.nextInt();	
		c.Sub(no, no1);
		break;
		}
		case 3:
		{
			System.out.println("Enter the two number ");
			int no=sc.nextInt ();
			int no1=sc.nextInt();
			c.Prod(no, no1);
			break;
		}
		case 4:
			
		{
			System.out.println("Enter the two number ");
			int no=sc.nextInt ();
			int no1=sc.nextInt();
			c.Div(no, no1);
			break;
		}
		default :
			System.out.println("Enter the no between 1-4");
		}
		System.out.println("Enter 1 to continue ");
		choice=sc.nextInt ();
		}while (choice==1);

}}
