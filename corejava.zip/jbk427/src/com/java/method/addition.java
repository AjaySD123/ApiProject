package com.java.method;

public class addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
