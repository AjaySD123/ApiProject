package com.java.method;

public class Calculator {


	void Add(int no,int no1)
	{
	System.out.println("the sum is "+no+no1);
	}
	void Sub (int no,int no1)
	{
		System.out.println("the sub ="+(no-no1)); 
	}
	void Prod (int no ,int no1)
	{
		System.out.println("the prod ="+(no*no1));
		
	}
	void Div(int no,int no1)
	{
		System.out.println("the div ="+(no/no1));
		
	}
}