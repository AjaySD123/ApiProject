package com.java.method;

public class mainexe1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    exercize1 obj=new exercize1();
    obj. Operation1();
    obj. display();
    obj. Operation2();
    obj. display();
    
	}
 
}
