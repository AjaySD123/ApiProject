package com.java.method;

public class Datatype_int {
	int a = 15000;
	int b= -20000;
	void add (){
		int c = a+b ;
	System.out.println("enter he number ");}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Datatype_int obj = new Datatype_int();
		obj.add();
		
	}

}
