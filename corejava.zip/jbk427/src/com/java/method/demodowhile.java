	package com.java.method;
	import java.util.Scanner;
	public class demodowhile {
		static	Scanner sc= new Scanner ( System.in );
	public static void main(){
		int a ;
	
		System.out.println("enter an int =");
		a =sc.nextInt();
	System.out.println("ajay");
		do {
		System.out.println("hello");
		a++;
		
		
	}	while (a<=8);
}


}
