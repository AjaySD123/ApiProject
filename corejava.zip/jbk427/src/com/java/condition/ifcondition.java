package com.java.condition;
import java.util.Scanner;
public class ifcondition {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("enter a number ");
		int a = scan.nextInt();
		scan.close();
System.out.println("print the a in="+a);
	}

}
