package com.java.condition;
import java. util.Scanner;
public class Billamt3_cust {
static Scanner sc= new Scanner (System.in);
int billamt1;
int billamt2;
int billamt3;
void BILLAMT(){
	System.out.println("eneter the billamt first custmor ");
	billamt1=sc.nextInt();
	System.out.println("eneter the billamt second  custmor ");
	billamt2=sc.nextInt();
	System.out.println("eneter the billamt third custmor ");
	billamt3=sc.nextInt();
int totalamt= billamt1+billamt2+billamt3;
System.out.println("total bill amount ="+totalamt);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Billamt3_cust obj=new  Billamt3_cust();
		obj.BILLAMT();
	}

}
