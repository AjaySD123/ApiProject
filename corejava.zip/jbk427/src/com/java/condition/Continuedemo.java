package com.java.condition;
import java.util.Scanner;
public class Continuedemo {
static Scanner sc=new Scanner (System.in);
void condition(){
	int no;
	System.out.println("enter the number no");
	no=sc.nextInt();
	int i;
	for ( i=1;i<no;i++){
		if (i%2==0)
		{
			System.out.println(i+"next is continue ");
			continue ;
		}
		else if (i==no){
			System.out.println("i is = no "+no);
			break;
		}
		System.out.println("ok"+i);
	}//loop end 
	System.out.println("done ");
	int cal =i+no+no ;
	System.out.println("total of sum of even no  ="+cal);
}

}

