package com.java.condition;
import java.util.Scanner;
public class Discount {
	int billamt;
void Accept (){
	Scanner sc=new Scanner (System.in);
	System.out.println("enter the bill amt ");
	billamt=sc.nextInt();
	if (billamt>1000)
		System.out.println("delivery is free");
		else if (billamt>=500&&billamt<=1000)
	System.out.println("dilivery charges are 50rs");
	else 
		System.out.println("delivary charges are 100rs");
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
Discount obj=new  Discount();
obj.Accept();

	}

}
