package com.java.condition;
import java.util.Scanner;
public class ife {
	static Scanner sc=new Scanner (System.in);


	
			
		
	
	public static void main(String[] args) {
		int n;
		System.out.println("enter the no ");
		n=sc.nextInt();
	if (n%2==0)
	{
		System.out.println("the no is even ");
	}
	else {
		System.out.println("The no is odd");
	}

	}

}

