package com.java.condition;
import java.util.Scanner;
//print the odd no upto 100
public class Forif {
static Scanner sc=new Scanner (System.in );
void disp(){
	for (int i=0;i<=100;i++){


			System.out.println("print i"+i);
	}
}

public static void main(String[] args) {
	Forif obj=new Forif ();
	obj.disp();
}
}	
