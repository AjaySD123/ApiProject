package com.java.condition;
import java.util.Scanner;
public class ifelse {
static Scanner sc=new Scanner(System.in);
void agecon( ){
	int age;
	System.out.println("enter your age ");
	age = sc.nextInt();
	if (age <= 18){
		System.out.println("you are able to do a job");
	}
	 else if (age>= 18){
		System.out.println("YOU are great to do a work");
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ifelse obj= new ifelse();
obj.agecon();
	}

}
