package com.java.condition;

public class main_continuebreak {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Continuedemo obj=new Continuedemo();
		obj.condition();
	}

}
