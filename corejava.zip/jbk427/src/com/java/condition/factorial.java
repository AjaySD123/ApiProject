package com.java.condition;
import java.util.Scanner;
public class factorial {
static Scanner sc=new Scanner (System.in);
public void Fact(){
	int no;
	
	System.out.println("enter the no"); 
	no= sc .nextInt();
	for (int i=0; i<=no; i++){
		 int fact = no * i;
		System.out.println("the factorial is "+fact);
	}
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
factorial obj = new factorial() ;
obj.Fact();

	}

}
