package com.java.condition;
import java.util.Scanner;
public class oddeven {
static Scanner sc=new Scanner(System.in);
void even(){
	int n;
	System.out.println("ener the integer ");
	n=sc.nextInt();
	if (n%2==0){
		System.out.println("The no is even");
		
	}
	else {
		System.out.println("the number is odd");
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
oddeven obj=new oddeven();
obj.even();

	}

}
