package com.java.condition;
import java.util.Scanner;
public class Billamt_3USINGLOOP {//write a program to disp the the total bill of 3 customer using for loop
static Scanner sc=new Scanner (System.in );


void billamount(){
	int b=0;
	System.out.println("eneter the bill amount ");
	for (int i=0;i<3;i++){
		int billamount=sc.nextInt();
		b =billamount+b;
			
	}
	System.out.println("the total bill ="+b);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Billamt_3USINGLOOP obj=new Billamt_3USINGLOOP();
		obj.billamount();
	}

}
